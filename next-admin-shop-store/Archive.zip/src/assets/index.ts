import logo from '@/assets/logo.png';
import login_bg from '@/assets/login_bg.jpg';

export { logo, login_bg };
