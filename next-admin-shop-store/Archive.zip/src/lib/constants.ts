export const ALLOWED_ROLES = ['ADMIN', 'USER', 'MANAGER'];
export const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
